Setup instructions for windows Flex

where python

cd C:\Users\xxxxxx\AppData\Local\Programs\Python\Python312\

cd Scripts

pip3 install requests

That should be all






